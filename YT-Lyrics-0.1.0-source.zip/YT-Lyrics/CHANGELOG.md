# Changelog

## 0.1.0
- Initial Fabric 26.2 client-side prototype.
- `/ytlyrics` player screen.
- Android MediaPlayer local-file playback backend.
- LRCLIB timed-lyrics lookup and HUD.
- GitHub Actions build workflow.

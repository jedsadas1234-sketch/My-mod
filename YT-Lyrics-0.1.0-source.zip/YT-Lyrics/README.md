# YT Lyrics

**Minecraft Java 26.2 · Fabric · Android/Zalith-first prototype**

YT Lyrics is a client-side music player and synchronized-lyrics HUD prototype.

## Important: what this first build does

Version 0.1.0 is the foundation:
- In-game player screen opened with `/ytlyrics`
- Local music library from the game folder
- Android playback through the Android `MediaPlayer` API (called reflectively, so the project does not need the Android SDK to compile)
- LRCLIB search for timed lyrics
- Synchronized in-game lyrics HUD

**YouTube playback is not implemented in this starter build.** YouTube does not provide a general public API that lets a third-party Minecraft mod stream arbitrary song audio directly. This project will not scrape protected YouTube streams or bypass playback restrictions. The player is structured so a future provider can be added if it has an authorized playback interface.

## Target versions

- Minecraft Java: `26.2`
- Fabric Loader: `0.19.3` or newer
- Fabric API: `0.155.2+26.2`
- Build JDK: `25`
- Fabric Loom: `1.17.21`
- Gradle: `9.5.1`

## How to use in Zalith

1. Build the mod JAR using the GitHub Actions workflow (instructions below).
2. Put `yt-lyrics-0.1.0.jar` in the `mods` folder for your **Fabric 26.2** profile.
3. Launch the game.
4. Open chat and run `/ytlyrics`.
5. The mod creates this folder inside the Minecraft game directory:

   `ytlyrics/music/`

6. Put audio files there. On Android, supported formats depend on the device's Android media codecs; try `.mp3`, `.m4a`, `.ogg`, or `.wav`.
7. Return to Minecraft, press **Scan**, select a track with **Next**, then press **Play**.
8. Enter the song title and artist and press **Find lyrics**. If LRCLIB has synchronized lyrics, the HUD follows the timestamps.

The first prototype targets Android/Zalith playback. A desktop playback backend is not included yet.

## Build with GitHub Actions (phone-friendly)

1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Open the **Actions** tab.
4. Run **Build YT Lyrics** using **Run workflow**, or push a commit.
5. Open the completed workflow run and download the `yt-lyrics-build` artifact.
6. Inside the artifact, use the JAR in `build/libs/` with the shortest filename (not the `-sources.jar`).

The workflow uses JDK 25 and Gradle 9.5.1.

## Notes

- Lyrics are requested from LRCLIB at runtime. Internet access is required for lyric search.
- The HUD only appears after lyrics have been loaded.
- This is an early prototype. Test it in a separate Minecraft profile and back up worlds before testing mods.
- No login, Google password, YouTube cookie, or session token is requested or stored.

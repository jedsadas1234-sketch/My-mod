package dev.tiwok.ytlyrics;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class LyricsService {
    private static final Pattern TIMESTAMP = Pattern.compile("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?\\]");
    private static final String API = "https://lrclib.net/api/search";

    private LyricsService() {
    }

    public static void search(String track, String artist) {
        String cleanTrack = track == null ? "" : track.trim();
        String cleanArtist = artist == null ? "" : artist.trim();

        if (cleanTrack.isBlank()) {
            ClientState.status = "Enter a song title first";
            return;
        }

        ClientState.status = "Searching LRCLIB...";
        CompletableFuture.runAsync(() -> {
            HttpURLConnection connection = null;
            try {
                String query = "track_name=" + encode(cleanTrack);
                if (!cleanArtist.isBlank()) query += "&artist_name=" + encode(cleanArtist);

                connection = (HttpURLConnection) new java.net.URL(API + "?" + query).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(10000);
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("User-Agent", "YT-Lyrics-Minecraft-Mod/0.1.0");

                int code = connection.getResponseCode();
                if (code < 200 || code >= 300) {
                    throw new IllegalStateException("LRCLIB returned HTTP " + code);
                }

                String body;
                try (InputStream in = connection.getInputStream();
                     ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    in.transferTo(out);
                    body = out.toString(StandardCharsets.UTF_8);
                }

                JsonArray results = JsonParser.parseString(body).getAsJsonArray();
                JsonObject best = null;
                JsonObject fallback = null;

                for (JsonElement element : results) {
                    if (!element.isJsonObject()) continue;
                    JsonObject item = element.getAsJsonObject();
                    if (fallback == null) fallback = item;
                    if (item.has("syncedLyrics") && !item.get("syncedLyrics").isJsonNull()
                        && !item.get("syncedLyrics").getAsString().isBlank()) {
                        best = item;
                        break;
                    }
                }

                if (best == null) best = fallback;
                if (best == null) throw new IllegalStateException("No matching lyrics found");

                String synced = stringValue(best, "syncedLyrics");
                String plain = stringValue(best, "plainLyrics");
                String resultTitle = stringValue(best, "trackName");
                String resultArtist = stringValue(best, "artistName");

                List<LyricLine> timed = parseSynced(synced);
                List<String> plainLines = splitPlain(plain);

                JsonObject finalBest = best;
                Minecraft.getInstance().execute(() -> {
                    ClientState.trackTitle = resultTitle.isBlank() ? cleanTrack : resultTitle;
                    ClientState.trackArtist = resultArtist.isBlank() ? cleanArtist : resultArtist;
                    ClientState.syncedLyrics = List.copyOf(timed);
                    ClientState.plainLyrics = List.copyOf(plainLines);
                    if (timed.isEmpty() && plainLines.isEmpty()) {
                        ClientState.status = "Match found, but no lyrics were supplied";
                    } else if (timed.isEmpty()) {
                        ClientState.status = "Lyrics loaded (not time-synced)";
                    } else {
                        ClientState.status = "Synced lyrics loaded";
                    }
                });
            } catch (Exception e) {
                YtLyrics.LOG.warn("Lyrics search failed", e);
                Minecraft.getInstance().execute(() ->
                    ClientState.status = "Lyrics search failed: " + safeMessage(e)
                );
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private static String encode(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8);
    }

    private static String stringValue(JsonObject object, String key) {
        JsonElement value = object.get(key);
        return value == null || value.isJsonNull() ? "" : value.getAsString();
    }

    private static String safeMessage(Exception e) {
        String message = e.getMessage();
        if (message == null || message.isBlank()) return e.getClass().getSimpleName();
        return message.length() > 70 ? message.substring(0, 70) : message;
    }

    private static List<LyricLine> parseSynced(String lrc) {
        List<LyricLine> lines = new ArrayList<>();
        if (lrc == null || lrc.isBlank()) return lines;

        for (String rawLine : lrc.split("\\R")) {
            Matcher matcher = TIMESTAMP.matcher(rawLine);
            List<Long> times = new ArrayList<>();
            int end = 0;

            while (matcher.find()) {
                long minutes = Long.parseLong(matcher.group(1));
                long seconds = Long.parseLong(matcher.group(2));
                String fraction = matcher.group(3);
                long millis = 0;
                if (fraction != null) {
                    if (fraction.length() == 1) millis = Long.parseLong(fraction) * 100L;
                    else if (fraction.length() == 2) millis = Long.parseLong(fraction) * 10L;
                    else millis = Long.parseLong(fraction);
                }
                times.add((minutes * 60L + seconds) * 1000L + millis);
                end = matcher.end();
            }

            String text = rawLine.substring(end).trim();
            if (text.isEmpty()) continue;
            for (long time : times) lines.add(new LyricLine(time, text));
        }

        lines.sort((a, b) -> Long.compare(a.timeMs(), b.timeMs()));
        return lines;
    }

    private static List<String> splitPlain(String plain) {
        if (plain == null || plain.isBlank()) return List.of();
        return plain.lines().map(String::trim).filter(s -> !s.isBlank()).toList();
    }
}

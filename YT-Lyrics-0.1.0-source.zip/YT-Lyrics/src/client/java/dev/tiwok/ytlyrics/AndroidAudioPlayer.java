package dev.tiwok.ytlyrics;

import java.lang.reflect.Method;
import java.nio.file.Path;

/**
 * Android-first playback backend.
 *
 * Android classes are accessed reflectively so the mod can compile without
 * depending on an Android SDK. Zalith runs inside Android, where MediaPlayer
 * is provided by the platform.
 */
public final class AndroidAudioPlayer {
    private static Object mediaPlayer;
    private static Method stopMethod;
    private static Method releaseMethod;
    private static Method positionMethod;
    private static boolean playing;

    private AndroidAudioPlayer() {
    }

    public static synchronized void play(Path file) throws Exception {
        stop();

        Class<?> type;
        try {
            type = Class.forName("android.media.MediaPlayer");
        } catch (ClassNotFoundException e) {
            throw new UnsupportedOperationException(
                "This prototype's playback backend currently targets Android/Zalith."
            );
        }

        Object player = type.getConstructor().newInstance();
        try {
            type.getMethod("setDataSource", String.class).invoke(player, file.toAbsolutePath().toString());
            type.getMethod("prepare").invoke(player);
            type.getMethod("start").invoke(player);

            mediaPlayer = player;
            stopMethod = type.getMethod("stop");
            releaseMethod = type.getMethod("release");
            positionMethod = type.getMethod("getCurrentPosition");
            playing = true;
        } catch (Exception e) {
            try {
                type.getMethod("release").invoke(player);
            } catch (Exception ignored) {
            }
            throw e;
        }
    }

    public static synchronized void stop() {
        Object player = mediaPlayer;
        mediaPlayer = null;
        playing = false;

        if (player == null) return;
        try {
            if (stopMethod != null) stopMethod.invoke(player);
        } catch (Exception ignored) {
        }
        try {
            if (releaseMethod != null) releaseMethod.invoke(player);
        } catch (Exception ignored) {
        }
        stopMethod = null;
        releaseMethod = null;
        positionMethod = null;
    }

    public static synchronized long positionMs() {
        if (!playing || mediaPlayer == null || positionMethod == null) return 0L;
        try {
            return ((Number) positionMethod.invoke(mediaPlayer)).longValue();
        } catch (Exception e) {
            return 0L;
        }
    }

    public static synchronized boolean isPlaying() {
        return playing;
    }
}

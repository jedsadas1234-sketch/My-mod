package dev.tiwok.ytlyrics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.nio.file.Path;
import java.util.List;

public final class PlayerScreen extends Screen {
    private EditBox titleInput;
    private EditBox artistInput;
    private List<Path> tracks = List.of();
    private int selectedTrack = -1;

    public PlayerScreen() {
        super(Component.literal("YT Lyrics"));
    }

    @Override
    protected void init() {
        int panelWidth = Math.min(330, this.width - 16);
        int left = (this.width - panelWidth) / 2;
        int top = Math.max(0, (this.height - 178) / 2);
        int innerWidth = panelWidth - 24;

        titleInput = new EditBox(this.font, left + 12, top + 28, innerWidth, 20, Component.literal("Song title"));
        titleInput.setHint(Component.literal("Song title"));
        addRenderableWidget(titleInput);

        artistInput = new EditBox(this.font, left + 12, top + 52, innerWidth, 20, Component.literal("Artist"));
        artistInput.setHint(Component.literal("Artist (optional)"));
        addRenderableWidget(artistInput);

        int gap = 6;
        int buttonWidth = (innerWidth - gap * 2) / 3;
        int row1 = top + 80;

        addRenderableWidget(Button.builder(Component.literal("Lyrics"), button -> {
            LyricsService.search(titleInput.getValue(), artistInput.getValue());
        }).bounds(left + 12, row1, buttonWidth, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Scan"), button -> {
            tracks = MusicLibrary.scan();
            selectedTrack = tracks.isEmpty() ? -1 : 0;
            ClientState.status = tracks.isEmpty()
                ? "No audio files. Add files to ytlyrics/music"
                : "Found " + tracks.size() + " audio file(s)";
            if (selectedTrack >= 0) {
                titleInput.setValue(MusicLibrary.displayName(tracks.get(selectedTrack)));
            }
        }).bounds(left + 12 + buttonWidth + gap, row1, buttonWidth, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Next"), button -> {
            if (tracks.isEmpty()) {
                ClientState.status = "Scan your music folder first";
                return;
            }
            selectedTrack = (selectedTrack + 1) % tracks.size();
            titleInput.setValue(MusicLibrary.displayName(tracks.get(selectedTrack)));
            ClientState.status = "Selected: " + tracks.get(selectedTrack).getFileName();
        }).bounds(left + 12 + (buttonWidth + gap) * 2, row1, buttonWidth, 20).build());

        int row2 = top + 104;
        addRenderableWidget(Button.builder(Component.literal("Play"), button -> playSelected())
            .bounds(left + 12, row2, buttonWidth, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Stop"), button -> {
            AndroidAudioPlayer.stop();
            ClientState.status = "Stopped";
        }).bounds(left + 12 + buttonWidth + gap, row2, buttonWidth, 20).build());

        addRenderableWidget(Button.builder(Component.literal("HUD on/off"), button -> {
            ClientState.hudEnabled = !ClientState.hudEnabled;
            ClientState.status = ClientState.hudEnabled ? "Lyrics HUD enabled" : "Lyrics HUD hidden";
        }).bounds(left + 12 + (buttonWidth + gap) * 2, row2, buttonWidth, 20).build());

        int row3 = top + 128;
        addRenderableWidget(Button.builder(Component.literal("Close"), button -> onClose())
            .bounds(left + 12, row3, innerWidth, 20).build());

        tracks = MusicLibrary.scan();
        selectedTrack = tracks.isEmpty() ? -1 : 0;
        if (selectedTrack >= 0) {
            titleInput.setValue(MusicLibrary.displayName(tracks.get(selectedTrack)));
        }
    }

    private void playSelected() {
        if (tracks.isEmpty() || selectedTrack < 0 || selectedTrack >= tracks.size()) {
            ClientState.status = "No track selected. Press Scan first.";
            return;
        }

        Path selected = tracks.get(selectedTrack);
        ClientState.status = "Loading " + selected.getFileName() + "...";

        Thread worker = new Thread(() -> {
            try {
                AndroidAudioPlayer.play(selected);
                Minecraft.getInstance().execute(() -> {
                    ClientState.trackTitle = MusicLibrary.displayName(selected);
                    ClientState.trackArtist = "";
                    ClientState.status = "Playing: " + selected.getFileName();
                });
            } catch (Exception e) {
                YtLyrics.LOG.warn("Playback failed", e);
                Minecraft.getInstance().execute(() ->
                    ClientState.status = "Playback failed: " + shortMessage(e)
                );
            }
        }, "YT-Lyrics-Audio");
        worker.setDaemon(true);
        worker.start();
    }

    private static String shortMessage(Exception e) {
        String message = e.getMessage();
        if (message == null || message.isBlank()) return e.getClass().getSimpleName();
        return message.length() > 70 ? message.substring(0, 70) : message;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);

        int panelWidth = Math.min(330, this.width - 16);
        int left = (this.width - panelWidth) / 2;
        int top = Math.max(0, (this.height - 178) / 2);

        graphics.fill(left, top, left + panelWidth, top + 178, 0xE9141824);
        graphics.outline(left, top, panelWidth, 178, 0xFF58647D);
        graphics.text(this.font, "YT LYRICS", left + 12, top + 8, 0xFFFFFFFF, true);
        graphics.text(this.font, "Local player · LRCLIB synced lyrics", left + 12, top + 18, 0xFF9DAAC2, false);

        String selected = selectedTrack >= 0 && selectedTrack < tracks.size()
            ? tracks.get(selectedTrack).getFileName().toString()
            : "No track selected";
        graphics.text(this.font, "Track: " + trim(selected, 38), left + 12, top + 151, 0xFFCAD4E8, false);

        graphics.text(this.font, "Status: " + trim(ClientState.status, 46), left + 12, top + 163, 0xFF8FD7C4, false);
        graphics.text(this.font, "Folder: .minecraft/ytlyrics/music", left + 12, top + 174, 0xFF8793AA, false);
    }

    private static String trim(String value, int max) {
        if (value == null) return "";
        return value.length() <= max ? value : value.substring(0, Math.max(0, max - 1)) + "…";
    }
}

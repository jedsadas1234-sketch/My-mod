package dev.tiwok.ytlyrics;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class MusicLibrary {
    private static final List<String> EXTENSIONS = List.of(".mp3", ".m4a", ".ogg", ".wav", ".flac");

    private MusicLibrary() {
    }

    public static Path musicFolder() {
        return FabricLoader.getInstance().getGameDir()
            .resolve("ytlyrics")
            .resolve("music");
    }

    public static void ensureMusicFolder() {
        try {
            Files.createDirectories(musicFolder());
        } catch (IOException e) {
            YtLyrics.LOG.error("Could not create music folder", e);
            ClientState.status = "Cannot create music folder";
        }
    }

    public static List<Path> scan() {
        ensureMusicFolder();
        try (var stream = Files.list(musicFolder())) {
            return stream
                .filter(Files::isRegularFile)
                .filter(MusicLibrary::isSupported)
                .sorted(Comparator.comparing(path -> path.getFileName().toString().toLowerCase(Locale.ROOT)))
                .toList();
        } catch (IOException e) {
            YtLyrics.LOG.error("Could not scan music folder", e);
            ClientState.status = "Music folder scan failed";
            return List.of();
        }
    }

    private static boolean isSupported(Path path) {
        String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
        return EXTENSIONS.stream().anyMatch(name::endsWith);
    }

    public static String displayName(Path path) {
        String name = path.getFileName().toString();
        int dot = name.lastIndexOf('.');
        if (dot > 0) name = name.substring(0, dot);
        return name.replace('_', ' ').replace('-', ' ');
    }
}

package dev.tiwok.ytlyrics;

public record LyricLine(long timeMs, String text) {
}

package dev.tiwok.ytlyrics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;

import java.util.List;

public final class LyricsHud {
    private LyricsHud() {
    }

    public static void render(GuiGraphicsExtractor graphics) {
        if (!ClientState.hudEnabled) return;

        List<LyricLine> lines = ClientState.syncedLyrics;
        List<String> plain = ClientState.plainLyrics;
        if (lines.isEmpty() && plain.isEmpty()) return;

        int guiWidth = graphics.guiWidth();
        int guiHeight = graphics.guiHeight();
        int boxWidth = Math.min(300, guiWidth - 20);
        int x = (guiWidth - boxWidth) / 2;
        int y = guiHeight - 58;

        graphics.fill(x, y, x + boxWidth, y + 48, 0xB80B1020);
        graphics.outline(x, y, boxWidth, 48, 0xAA7B8EAA);

        Minecraft client = Minecraft.getInstance();
        graphics.text(client.font, "YT LYRICS", x + 8, y + 5, 0xFF8FD7C4, false);

        if (!lines.isEmpty()) {
            int index = ClientState.lyricIndexAt(AndroidAudioPlayer.positionMs());
            if (index < 0) index = 0;
            String current = lines.get(Math.min(index, lines.size() - 1)).text();
            String next = index + 1 < lines.size() ? lines.get(index + 1).text() : "";

            graphics.centeredText(client.font, Component.literal(trim(current, 48)),
                guiWidth / 2, y + 19, 0xFFFFFFFF);
            if (!next.isBlank()) {
                graphics.centeredText(client.font, Component.literal(trim(next, 48)),
                    guiWidth / 2, y + 33, 0xFF9DAAC2);
            }
        } else {
            String first = plain.isEmpty() ? "Lyrics loaded" : plain.get(0);
            graphics.centeredText(client.font, Component.literal(trim(first, 48)),
                guiWidth / 2, y + 25, 0xFFFFFFFF);
        }
    }

    private static String trim(String value, int max) {
        if (value == null) return "";
        return value.length() <= max ? value : value.substring(0, Math.max(0, max - 1)) + "…";
    }
}

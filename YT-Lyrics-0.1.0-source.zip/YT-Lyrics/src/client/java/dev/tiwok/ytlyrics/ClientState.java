package dev.tiwok.ytlyrics;

import java.util.List;

public final class ClientState {
    public static volatile String status = "Ready";
    public static volatile String trackTitle = "";
    public static volatile String trackArtist = "";
    public static volatile List<LyricLine> syncedLyrics = List.of();
    public static volatile List<String> plainLyrics = List.of();
    public static volatile boolean hudEnabled = true;

    private ClientState() {
    }

    public static int lyricIndexAt(long positionMs) {
        List<LyricLine> lines = syncedLyrics;
        if (lines.isEmpty()) return -1;

        int index = 0;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).timeMs() <= positionMs) {
                index = i;
            } else {
                break;
            }
        }
        return index;
    }

    public static void clearLyrics() {
        syncedLyrics = List.of();
        plainLyrics = List.of();
    }
}

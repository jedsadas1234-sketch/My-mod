package dev.tiwok.ytlyrics;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public final class YtLyricsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        MusicLibrary.ensureMusicFolder();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommands.literal("ytlyrics").executes(context -> {
                Minecraft client = context.getSource().getClient();
                client.execute(() -> client.gui.setScreen(new PlayerScreen()));
                context.getSource().sendFeedback(Component.literal("Opening YT Lyrics..."));
                return 1;
            }))
        );

        HudElementRegistry.addLast(
            Identifier.fromNamespaceAndPath("ytlyrics", "lyrics_hud"),
            (graphics, deltaTracker) -> LyricsHud.render(graphics)
        );

        YtLyrics.LOG.info("YT Lyrics 0.1.0 initialized. Open with /ytlyrics");
    }
}

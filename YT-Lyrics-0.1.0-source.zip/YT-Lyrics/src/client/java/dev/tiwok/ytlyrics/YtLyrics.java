package dev.tiwok.ytlyrics;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class YtLyrics {
    public static final String MOD_ID = "ytlyrics";
    public static final Logger LOG = LoggerFactory.getLogger(MOD_ID);

    private YtLyrics() {
    }
}
